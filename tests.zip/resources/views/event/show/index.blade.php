<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Show | Event</title>
</head>

<body>
    <form method="post">
        {{@csrf_field()}}
        <h1> {{$event->event_name}}</h1>
        <hr>

        <p>
            <a href="{{route('event.edit',[$event->id])}}">Edit event</a>
        </p>


        <table>
            <tr>
                <td><strong>Event Details: </strong></td>
                <td>{{$event->event_details}}</td>
            </tr>

            <tr>
                <td><strong>Importance </strong></td>
                <td>{{$event->importance}}</td>
            </tr>

        </table>
<br><br>
        <p>Want to delete event???</p>
        <input type="submit" value="Yes">

    </form>
</body>

</html>

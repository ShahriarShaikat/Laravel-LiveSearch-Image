<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Show | Event</title>
</head>

<body>
    <form method="post">
        <?php echo e(@csrf_field()); ?>

        <h1> <?php echo e($event->event_name); ?></h1>
        <hr>

        <p>
            <a href="<?php echo e(route('event.edit',[$event->id])); ?>">Edit event</a>
        </p>


        <table>
            <tr>
                <td><strong>Event Details: </strong></td>
                <td><?php echo e($event->event_details); ?></td>
            </tr>

            <tr>
                <td><strong>Importance </strong></td>
                <td><?php echo e($event->importance); ?></td>
            </tr>

        </table>
<br><br>
        <p>Want to delete event???</p>
        <input type="submit" value="Yes">

    </form>
</body>

</html>

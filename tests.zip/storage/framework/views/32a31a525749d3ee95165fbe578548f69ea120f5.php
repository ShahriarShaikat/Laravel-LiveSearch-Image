<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home | Page</title>
</head>
<body>
  <br><br>
   <a href="<?php echo e(route('logout.index')); ?>">Logout</a> | 
   <a href="<?php echo e(route('user.create')); ?>">Add New Event</a>
    <h1>Events List of <?php echo e(session('username')); ?></h1>
    
    <table border="1">
        <tr>
            <th>Event Name</th>
            <th>Event Details</th>
            <th>Importance</th>
        </tr>

        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><a href="<?php echo e(route('event.show',[$event->id])); ?>"><?php echo e($event->event_name); ?></a></td>
            
            <td><?php echo e($event->event_details); ?></td>
            <td><?php echo e($event->importance); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    
</body>
</html>